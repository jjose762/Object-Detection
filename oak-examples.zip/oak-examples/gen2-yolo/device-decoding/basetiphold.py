#!/usr/bin/env python3
import os, time, csv, signal, json, math
from collections import deque
import cv2, numpy as np
import depthai as dai
from datetime import datetime

# ===================== Paths and IO =====================
JSON_PATH = "/home/team18/Documents/pleasework/oak-examples/gen2-yolo/device-decoding/AugmentedModel/best_aug.json"

OUT_DIR        = "/home/team18/Documents/pleasework/oak-examples/gen2-yolo/device-decoding/LIVE FRAMES"
OUT_DIR_SNAPS  = os.path.join(OUT_DIR, "LIVE SNAPSHOTS")
OUT_DIR_CSV    = os.path.join(OUT_DIR, "LIVE CSV")

LATEST         = os.path.join(OUT_DIR, "live.jpg")
CSV_POSE_PATH  = os.path.join(OUT_DIR_CSV, "pose_log.csv")          # APPEND across runs
CSV_DET_PATH   = os.path.join(OUT_DIR_CSV, "detections.csv")        # start_datetime,end_datetime,labels
CSV_GAUGE_PATH = os.path.join(OUT_DIR_CSV, "gauge.csv")             # datetime,angle_deg,bars
STATE_PATH     = os.path.join(OUT_DIR, "aruco_last_dict.json")      # saves last good ArUco dictionary
SNAP_DIR       = os.path.join(OUT_DIR_SNAPS, "snapshots")

JPEG_QUALITY = 95

# --- MJPEG settings ---
USE_MJPEG        = False
MJPEG_PATH       = os.path.join(OUT_DIR, "live.avi")   # MJPEG-in-AVI
MJPEG_FPS        = 30
WRITE_JPEG_EVERY = 1                                  # write live.jpg every N frames (0 = disable)

os.makedirs(OUT_DIR, exist_ok=True)
os.makedirs(OUT_DIR_SNAPS, exist_ok=True)
os.makedirs(OUT_DIR_CSV, exist_ok=True)
os.makedirs(SNAP_DIR, exist_ok=True)

# make CSVs if missing and set header for detection and gauge
if not os.path.exists(CSV_DET_PATH):
    with open(CSV_DET_PATH, "w") as _f:
        _f.write("start_datetime,end_datetime,labels\n")
if not os.path.exists(CSV_GAUGE_PATH):
    with open(CSV_GAUGE_PATH, "w") as _f:
        _f.write("datetime,angle_deg,bars\n")

# ===================== Camera and NN =====================
cfg  = json.load(open(JSON_PATH, "r"))
blob = cfg["model"]
if isinstance(blob, dict):
    blob = blob.get("blob", blob.get("xml", None))

nnc       = cfg.get("nn_config", {})
meta      = nnc.get("NN_specific_metadata", {})
labels    = cfg.get("mappings", {}).get("labels", [])

W, H = map(int, nnc.get("input_size", "640x640").split("x"))  # align manip and pose intrinsics to NN size
num_classes = int(meta.get("classes", len(labels) or 80))
coord_size  = int(meta.get("coordinates", 4))
anchors     = list(map(float, meta.get("anchors", [])))
anchor_masks= meta.get("anchor_masks", {})
iou_thr     = float(meta.get("iou_threshold", 0.5))
conf_thr    = float(meta.get("confidence_threshold", 0.5))

# ===================== ArUco Settings =====================
MARKER_SIZE_M = 0.20
DICT_CANDIDATES = [
    "DICT_4X4_50","DICT_4X4_100","DICT_4X4_250",
    "DICT_5X5_50","DICT_5X5_100","DICT_5X5_250",
    "DICT_6X6_50","DICT_6X6_100","DICT_6X6_250",
    "DICT_ARUCO_ORIGINAL",
]
SEARCH_TIMEOUT_S = 6.0
RELOCK_AFTER_S   = 5.0
AXIS_LEN_M       = 0.15
AXIS_THICK       = 8

# ===================== Gauge Calibration =====================
CAL_A_DEG = 212.6; CAL_A_BAR = 3.0
CAL_B_DEG = 270.0; CAL_B_BAR = 5.0
GAUGE_MAX_BAR = 10.0

def _cw_delta(a, b): return (b - a) % 360.0
DEG_PER_BAR    = _cw_delta(CAL_A_DEG, CAL_B_DEG) / (CAL_B_BAR - CAL_A_BAR)
GAUGE_ZERO_DEG = (CAL_A_DEG - CAL_A_BAR * DEG_PER_BAR) % 360.0

# ===================== Filters and windowing =====================
SNAPSHOT_MIN_GAP_SEC = 10.0
DET_WINDOW_SEC = 5.0
ARUCO_MAX_RATIO = 1.7
OPEN_CONFIRM_K, OPEN_CONFIRM_N = 2, 3
open_present_hist = deque([0]*OPEN_CONFIRM_N, maxlen=OPEN_CONFIRM_N)

# Use the most recent Base/Tip seen within this window
COUPLE_WINDOW_SEC = 3.0

# ===================== Helpers =====================
def label_name(i): 
    return labels[i] if 0 <= i < len(labels) else str(i)

def now_local_ms():
    t = time.time()
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t)) + f".{int((t%1)*1000):03d}"

def ts_to_local_ms(ts):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)) + f".{int((ts%1)*1000):03d}"

def write_atomic_jpg(path, img, quality=80):
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
    if not ok: 
        return False
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(buf.tobytes())
    os.replace(tmp, path)
    return True

def save_snapshot_jpg(dirpath, frame, quality):
    ts = time.strftime("%Y%m%d_%H%M%S")
    ms = int((time.time()%1)*1000)
    path = os.path.join(dirpath, f"{ts}_{ms:03d}.jpg")
    cv2.imwrite(path, frame, [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
    return path

def append_csv_detection_window(path, start_dt, end_dt, labels_list):
    labels_str = ", ".join(sorted(set(labels_list)))
    with open(path, "a") as f:
        f.write(f"{start_dt},{end_dt},{labels_str}\n")

def append_csv_gauge(path, dt, angle_deg, bars):
    with open(path, "a") as f:
        f.write(f"{dt},{angle_deg:.1f},{bars:.3f}\n")

def load_last_dict():
    try:
        with open(STATE_PATH, "r") as f:
            return json.load(f).get("dict_name")
    except Exception:
        return None

def save_last_dict(name):
    try:
        with open(STATE_PATH, "w") as f:
            json.dump({"dict_name": name, "ts": time.time()}, f)
    except Exception:
        pass

def make_aruco_detector(dict_name):
    dval = getattr(cv2.aruco, dict_name)
    dictionary = cv2.aruco.getPredefinedDictionary(dval)
    if hasattr(cv2.aruco, "DetectorParameters"):
        params = cv2.aruco.DetectorParameters()
        params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
        det = cv2.aruco.ArucoDetector(dictionary, params)
        return (lambda gray: det.detectMarkers(gray)), dict_name
    else:
        params = cv2.aruco.DetectorParameters_create()
        params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
        return (lambda gray: cv2.aruco.detectMarkers(gray, dictionary, parameters=params)), dict_name

def try_detect_aruco(det_fn, gray):
    out = det_fn(gray)
    if len(out) == 3: corners, ids, _ = out
    else: corners, ids = out
    return corners, ids

def draw_axes_bold(img, K, D, rvec, tvec, axis_len_m=0.15, thickness=8):
    axis = np.float32([[0,0,0],[axis_len_m,0,0],[0,axis_len_m,0],[0,0,axis_len_m]]).reshape(-1,3)
    pts2d, _ = cv2.projectPoints(axis, rvec, tvec, K, D)
    pts2d = np.int32(pts2d).reshape(-1,2)
    O, X, Y, Z = pts2d
    for pt in (X, Y, Z):
        cv2.line(img, O, pt, (0,0,0), thickness+4, cv2.LINE_AA)
    cv2.line(img, O, X, (0,0,255), thickness, cv2.LINE_AA)
    cv2.line(img, O, Y, (0,255,0), thickness, cv2.LINE_AA)
    cv2.line(img, O, Z, (255,0,0), thickness, cv2.LINE_AA)

def put_text_bold(img, text, org, scale=0.7, color=(0,255,255)):
    cv2.putText(img, text, (org[0]+1, org[1]+1), cv2.FONT_HERSHEY_SIMPLEX, scale, (0,0,0), 3, cv2.LINE_AA)
    cv2.putText(img, text, org,                  cv2.FONT_HERSHEY_SIMPLEX, scale, color,     2, cv2.LINE_AA)

def rvec_to_euler_xyz_deg(rvec):
    R, _ = cv2.Rodrigues(rvec.reshape(3,1))
    R = np.asarray(R, dtype=np.float64)
    pitch = -np.arcsin(np.clip(R[2,0], -1.0, 1.0))
    roll  = np.arctan2(R[2,1], R[2,2])
    yaw   = np.arctan2(R[1,0], R[0,0])
    return np.degrees([roll, pitch, yaw])

def safe_box(det, Wf, Hf):
    def _f(val):
        try: return float(val)
        except: return float("nan")
    xmin, ymin, xmax, ymax = map(_f, (getattr(det,"xmin",None), getattr(det,"ymin",None),
                                      getattr(det,"xmax",None), getattr(det,"ymax",None)))
    if any(map(lambda v: v is None or math.isnan(v) or math.isinf(v), [xmin,ymin,xmax,ymax])):
        return None
    x1 = int(max(0, min(Wf-1, round(xmin*Wf))))
    y1 = int(max(0, min(Hf-1, round(ymin*Hf))))
    x2 = int(max(0, min(Wf-1, round(xmax*Wf))))
    y2 = int(max(0, min(Hf-1, round(ymax*Hf))))
    if x2 <= x1 or y2 <= y1: return None
    return x1,y1,x2,y2

def aspect_ratio_ge1(x1,y1,x2,y2):
    w = max(1, x2 - x1); h = max(1, y2 - y1)
    return (w/h) if w >= h else (h/w)

def is_aruco_label(name):
    ln = name.strip().lower()
    return ln in ("aruco", "aurcomarker", "arucomarker", "aurco", "arucomarker")

def is_tip(name):  return name.strip().lower() == "tip"
def is_base(name): return name.strip().lower() == "base"
def is_openvalve(name): return name.strip().lower() == "openvalve"

def bars_from_angle(angle_deg):
    progress_cw = (angle_deg - GAUGE_ZERO_DEG) % 360.0
    bars = progress_cw / DEG_PER_BAR
    if bars < 0.0: bars = 0.0
    if bars > GAUGE_MAX_BAR: bars = GAUGE_MAX_BAR
    return bars

# ===================== Pipeline =====================
p = dai.Pipeline()
cam = p.create(dai.node.ColorCamera)
cam.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
cam.setInterleaved(False)
cam.setColorOrder(dai.ColorCameraProperties.ColorOrder.BGR)

manip = p.create(dai.node.ImageManip)
manip.initialConfig.setResize(W, H)
manip.initialConfig.setFrameType(dai.ImgFrame.Type.BGR888p)
manip.setMaxOutputFrameSize(W * H * 3)

yolo = p.create(dai.node.YoloDetectionNetwork)
yolo.setBlobPath(blob)
yolo.setConfidenceThreshold(conf_thr)
yolo.setNumClasses(num_classes)
yolo.setCoordinateSize(coord_size)
if anchors: yolo.setAnchors(anchors)
if anchor_masks: yolo.setAnchorMasks(anchor_masks)
yolo.setIouThreshold(iou_thr)

cam.preview.link(manip.inputImage)
manip.out.link(yolo.input)

xout_frames = p.create(dai.node.XLinkOut); xout_frames.setStreamName("frames")
manip.out.link(xout_frames.input)

xout_dets = p.create(dai.node.XLinkOut); xout_dets.setStreamName("detections")
yolo.out.link(xout_dets.input)

# ===================== Run =====================
stop = False
def _sig(a,b):
    global stop; stop=True
signal.signal(signal.SIGINT, _sig)
signal.signal(signal.SIGTERM, _sig)

def main():
    global stop
    stop = False

    if not hasattr(cv2, "aruco"):
        print("OpenCV contrib ArUco not found. Install: pip install opencv-contrib-python==4.12.0.88")
        return

    # build ArUco candidate detectors
    cands = []
    for name in DICT_CANDIDATES:
        if hasattr(cv2.aruco, name):
            cands.append(make_aruco_detector(name))
    if not cands:
        print("No ArUco dictionaries available in this OpenCV build.")
        return
    print("[init] ArUco dict candidates:", [n for _, n in cands])

    # --- pose CSV append across runs ---
    need_header = (not os.path.exists(CSV_POSE_PATH)) or (os.path.getsize(CSV_POSE_PATH) == 0)
    with open(CSV_POSE_PATH, "a", newline="") as csv_pose_file:
        pose_writer = csv.writer(csv_pose_file)
        if need_header:
            pose_writer.writerow([
                "timestamp_local","id",
                "x_m","y_m","z_m",
                "rvec_x","rvec_y","rvec_z",
                "roll_deg","pitch_deg","yaw_deg",
                "dictionary"
            ])
            csv_pose_file.flush(); os.fsync(csv_pose_file.fileno())
            print(f"[init] Wrote pose CSV header: {CSV_POSE_PATH}")

        vw = None  # MJPEG writer
        try:
            with dai.Device(p) as dev:
                calib = dev.readCalibration()
                # intrinsics aligned to manip size
                K = np.array(calib.getCameraIntrinsics(dai.CameraBoardSocket.CAM_A, W, H), dtype=np.float32)
                D = np.array(calib.getDistortionCoefficients(dai.CameraBoardSocket.CAM_A), dtype=np.float32)
                print("[calib] K=\n", K); print("[calib] D=", D.flatten().tolist())

                qF = dev.getOutputQueue("frames",     maxSize=4, blocking=False)
                qD = dev.getOutputQueue("detections", maxSize=4, blocking=False)

                # warm start dictionary
                chosen = None
                chosen_until = 0.0
                last_dict_name = load_last_dict()
                if last_dict_name and hasattr(cv2.aruco, last_dict_name):
                    print(f"[warm] Trying last dict first: {last_dict_name}")
                    chosen = make_aruco_detector(last_dict_name)
                    chosen_until = time.time() + SEARCH_TIMEOUT_S

                frames, t_prev, t_log, fps = 0, time.time(), time.time(), 0.0
                last_seen_ts = 0.0

                prev_confirmed = set()
                last_snap_ts   = 0.0
                det_win_start_ts = None
                det_win_labels   = set()
                det_last_seen_ts = None

                # --- Base/Tip caches for sliding window coupling ---
                last_base_center, last_base_ts = None, 0.0
                last_tip_center,  last_tip_ts  = None, 0.0

                print(f"✅ Writing preview to: {LATEST} (throttled every {WRITE_JPEG_EVERY} frames)" if WRITE_JPEG_EVERY else "✅ live.jpg disabled")
                if USE_MJPEG:
                    print(f"🎥 Writing MJPEG to: {MJPEG_PATH} @ {MJPEG_FPS} fps")

                while not stop:
                    # pull latest frame and detections to keep latency low
                    f = qF.tryGet()
                    while True:
                        f2 = qF.tryGet()
                        if f2 is None: break
                        f = f2

                    d = qD.tryGet()
                    while True:
                        d2 = qD.tryGet()
                        if d2 is None: break
                        d = d2

                    if f is None:
                        time.sleep(0.001); 
                        continue

                    frame = f.getCvFrame()            # WxH BGR
                    Hf, Wf = frame.shape[:2]
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

                    dets = d.detections if (d is not None and hasattr(d,"detections")) else []

                    # -------- YOLO draw and filtering ----------
                    present_labels = []
                    base_center, base_best = None, -1.0
                    tip_center,  tip_best  = None, -1.0

                    for det in dets:
                        box = safe_box(det, Wf, Hf)
                        if not box:
                            continue
                        x1,y1,x2,y2 = box
                        name = label_name(int(getattr(det, "label", -1)))
                        conf = float(getattr(det, "confidence", 0.0))

                        # ArUco-like class: keep only near square to reject elongated false positives
                        if is_aruco_label(name):
                            ratio = aspect_ratio_ge1(x1,y1,x2,y2)
                            if ratio > ARUCO_MAX_RATIO:
                                continue

                        # draw accepted boxes
                        cv2.rectangle(frame, (x1,y1), (x2,y2), (0,255,0), 2)
                        cv2.putText(frame, f"{name} {conf:.2f}",
                                    (x1, max(15, y1-6)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 1)

                        present_labels.append(name)

                        # best Base and Tip for angle (this frame)
                        cx = 0.5 * (x1 + x2)
                        cy = 0.5 * (y1 + y2)
                        if is_base(name) and conf > base_best:
                            base_best = conf
                            base_center = (cx, cy)
                        if is_tip(name) and conf > tip_best:
                            tip_best = conf
                            tip_center = (cx, cy)

                    # FPS overlay
                    now = time.time()
                    if frames > 0 and (now - t_prev) > 0:
                        fps = 0.9*fps + 0.1*(1.0/(now - t_prev))
                    t_prev = now
                    cv2.putText(frame, f"{time.strftime('%H:%M:%S')}  FPS~{fps:.1f}",
                                (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

                    # --- OpenValve multi-frame confirmation
                    lowers = [lbl.strip().lower() for lbl in present_labels]
                    open_here = 1 if "openvalve" in lowers else 0
                    open_present_hist.append(open_here)
                    open_confirmed = (sum(open_present_hist) >= OPEN_CONFIRM_K)

                    confirmed_labels = list(present_labels)
                    if "openvalve" in lowers and not open_confirmed:
                        confirmed_labels = [lbl for lbl in confirmed_labels if lbl.strip().lower() != "openvalve"]

                    # --- Update Base/Tip caches from THIS frame (if present)
                    if base_center is not None:
                        last_base_center, last_base_ts = base_center, now
                    if tip_center is not None:
                        last_tip_center, last_tip_ts = tip_center, now

                    # --- Gauge angle & pressure using most recent Base/Tip within last N seconds
                    use_cached = (
                        (last_base_center is not None) and (last_tip_center is not None) and
                        ((now - last_base_ts) <= COUPLE_WINDOW_SEC) and
                        ((now - last_tip_ts)  <= COUPLE_WINDOW_SEC)
                    )
                    if use_cached:
                        dx = last_tip_center[0] - last_base_center[0]
                        dy = last_tip_center[1] - last_base_center[1]  # +y is down
                        angle_deg = (math.degrees(math.atan2(dy, dx)) % 360.0)
                        bars = bars_from_angle(angle_deg)
                        append_csv_gauge(CSV_GAUGE_PATH, now_local_ms(), angle_deg, bars)

                        # Visual overlay from cached points
                        bpt = (int(last_base_center[0]), int(last_base_center[1]))
                        tpt = (int(last_tip_center[0]),  int(last_tip_center[1]))
                        cv2.circle(frame, bpt, 5, (0,255,255), -1)
                        cv2.arrowedLine(frame, bpt, tpt, (255,255,0), 2, tipLength=0.2)
                        tx = max(8, min(Wf - 260, tpt[0] + 8))
                        ty = max(18, min(Hf - 8,  tpt[1] - 8))
                        cv2.putText(frame, f"{angle_deg:.1f}°  {bars:.2f} bar",
                                    (tx, ty), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,0), 2)

                    # --- ArUco pose detection and overlay
                    corners = ids = None
                    dict_name = None
                    if chosen is not None:
                        det_fn, dict_name = chosen
                        corners, ids = try_detect_aruco(det_fn, gray)
                        if (ids is None or len(ids) == 0) and time.time() > chosen_until:
                            print("[scan] Warm start failed. Scanning all dictionaries")
                            chosen = None

                    if chosen is None and (ids is None or len(ids) == 0):
                        for det_fn, nm in cands:
                            c, i = try_detect_aruco(det_fn, gray)
                            if i is not None and len(i) > 0:
                                chosen = (det_fn, nm)
                                dict_name = nm
                                corners, ids = c, i
                                save_last_dict(nm)
                                print(f"[lock] Using dictionary: {nm} (saved)")
                                break

                    if ids is not None and len(ids) > 0:
                        cv2.aruco.drawDetectedMarkers(frame, corners, ids)
                        rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(corners, MARKER_SIZE_M, K, D)
                        for rvec, tvec, mid in zip(rvecs, tvecs, ids.flatten()):
                            draw_axes_bold(frame, K, D, rvec, tvec, axis_len_m=AXIS_LEN_M, thickness=AXIS_THICK)
                            x,y,z = (float(tvec[0][0]), float(tvec[0][1]), float(tvec[0][2]))
                            rx,ry,rz = (float(rvec[0][0]), float(rvec[0][1]), float(rvec[0][2]))
                            roll_deg, pitch_deg, yaw_deg = rvec_to_euler_xyz_deg(np.array([rx,ry,rz], dtype=np.float64))

                            put_text_bold(frame, f"id{int(mid)} {dict_name}", (10, 30))
                            put_text_bold(frame, f"X:{x:+.3f}m  Y:{y:+.3f}m  Z:{z:+.3f}m", (10, 62))
                            put_text_bold(frame, f"Roll:{roll_deg:+6.1f}°  Pitch:{pitch_deg:+6.1f}°  Yaw:{yaw_deg:+6.1f}°",
                                          (10, 94), scale=0.65, color=(255,255,0))

                            # log pose to CSV
                            pose_writer.writerow([now_local_ms(), int(mid), x, y, z, rx, ry, rz,
                                                  float(roll_deg), float(pitch_deg), float(yaw_deg), dict_name or ""])
                            csv_pose_file.flush()
                        last_seen_ts = time.time()
                    else:
                        put_text_bold(frame, "No ArUco detected", (10, Hf-16), scale=0.7, color=(0,0,255))
                        if last_seen_ts>0 and (time.time()-last_seen_ts)>RELOCK_AFTER_S:
                            if chosen is not None: print("[relock] Lost marker. Rescanning dictionaries")
                            chosen=None; chosen_until=0.0; last_seen_ts=0.0

                    # --- Detection windowing and snapshots
                    if confirmed_labels:
                        if det_win_start_ts is None:
                            det_win_start_ts = now
                            det_win_labels.clear()
                        det_win_labels.update(confirmed_labels)
                        det_last_seen_ts = now

                        if (now - det_win_start_ts) >= DET_WINDOW_SEC:
                            append_csv_detection_window(
                                CSV_DET_PATH,
                                ts_to_local_ms(det_win_start_ts),
                                ts_to_local_ms(now),
                                list(det_win_labels)
                            )
                            det_win_start_ts = now
                            det_win_labels.clear()

                        curr_set = set(confirmed_labels)
                        new_labels = curr_set - prev_confirmed
                        should_snapshot = bool(new_labels) or ((now - last_snap_ts) >= SNAPSHOT_MIN_GAP_SEC)
                        if should_snapshot:
                            save_snapshot_jpg(SNAP_DIR, frame, JPEG_QUALITY)
                            last_snap_ts = now

                        prev_confirmed = curr_set
                    else:
                        if det_win_start_ts is not None and det_last_seen_ts is not None and det_win_labels:
                            append_csv_detection_window(
                                CSV_DET_PATH,
                                ts_to_local_ms(det_win_start_ts),
                                ts_to_local_ms(det_last_seen_ts),
                                list(det_win_labels)
                            )
                        det_win_start_ts = None
                        det_win_labels.clear()
                        det_last_seen_ts = None
                        prev_confirmed = set()

                    # --- Write outputs (after overlays) ---
                    if USE_MJPEG:
                        if vw is None:
                            fourcc = cv2.VideoWriter_fourcc(*"MJPG")
                            vw = cv2.VideoWriter(MJPEG_PATH, fourcc, float(MJPEG_FPS), (Wf, Hf))
                            if not vw.isOpened():
                                print(f"[warn] Failed to open MJPEG writer at {MJPEG_PATH}")
                                vw = None
                        if vw is not None:
                            vw.write(frame)

                    if WRITE_JPEG_EVERY and (frames % WRITE_JPEG_EVERY == 0):
                        write_atomic_jpg(LATEST, frame, JPEG_QUALITY)

                    frames += 1
                    if now - t_log >= 1.0:
                        print(f"[updated] frames:{frames}  fps~{fps:.1f}")
                        t_log = now

                # final flush on exit
                if det_win_start_ts is not None and det_last_seen_ts is not None and det_win_labels:
                    append_csv_detection_window(
                        CSV_DET_PATH,
                        ts_to_local_ms(det_win_start_ts),
                        ts_to_local_ms(det_last_seen_ts),
                        list(det_win_labels)
                    )
        except Exception as e:
            print(f"[error] Failed to open OAK device: {e!r}")
            return
        finally:
            if vw is not None:
                vw.release()
                print(f"[mjpeg] Closed {MJPEG_PATH}")

    print("✅ Stopped.")

if __name__ == "__main__":
    main()
# ===================== End of File =====================
