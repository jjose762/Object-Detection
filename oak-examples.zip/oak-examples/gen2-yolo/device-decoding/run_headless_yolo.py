#!/usr/bin/env python3
import json, os, time, signal, math
import depthai as dai
import cv2

# --- paths: OLD working config ---
JSON_PATH = "/home/team18/Documents/pleasework/oak-examples/gen2-yolo/device-decoding/AugmentedModel/best_aug.json"  # this JSON contains: "model": "/home/team18/Documents/best_openvino_2021.4_6shave.blob"
OUT_DIR   = "/home/team18/Documents/pleasework/oak-examples/gen2-yolo/device-decoding/LIVE FRAMES"
LATEST    = os.path.join(OUT_DIR, "live.jpg")
JPEG_QUALITY = 95

os.makedirs(OUT_DIR, exist_ok=True)

# --- load config ---
cfg  = json.load(open(JSON_PATH, "r"))
blob = cfg["model"]
nnc  = cfg["nn_config"]
meta = nnc.get("NN_specific_metadata", {})
labels = cfg.get("mappings", {}).get("labels", [])

W, H = map(int, nnc.get("input_size", "640x640").split("x"))  # 416x416 for the old model
num_classes = int(meta.get("classes", len(labels) or 80))
coord_size  = int(meta.get("coordinates", 4))
anchors     = list(map(float, meta.get("anchors", [])))
anchor_masks= meta.get("anchor_masks", {})
iou_thr     = float(meta.get("iou_threshold", 0.5))
conf_thr    = float(meta.get("confidence_threshold", 0.5))

# --- pipeline (non-spatial YOLO; planar into NN via ImageManip) ---
p = dai.Pipeline()

cam = p.create(dai.node.ColorCamera)
cam.setResolution(dai.ColorCameraProperties.SensorResolution.THE_1080_P)
cam.setInterleaved(False)
cam.setColorOrder(dai.ColorCameraProperties.ColorOrder.BGR)

manip = p.create(dai.node.ImageManip)
manip.initialConfig.setResize(W, H)
manip.initialConfig.setFrameType(dai.ImgFrame.Type.BGR888p)  # planar CHW for NN
manip.setMaxOutputFrameSize(W * H * 3)                      # 416*416*3 = 519,168 bytes

yolo = p.create(dai.node.YoloDetectionNetwork)
if isinstance(blob, dict):
    blob = blob.get("blob", None)
yolo.setBlobPath(blob)
yolo.setConfidenceThreshold(conf_thr)
yolo.setNumClasses(num_classes)
yolo.setCoordinateSize(coord_size)
if anchors: yolo.setAnchors(anchors)
if anchor_masks: yolo.setAnchorMasks(anchor_masks)
yolo.setIouThreshold(iou_thr)

# links
cam.preview.link(manip.inputImage)
manip.out.link(yolo.input)

xout_frames = p.create(dai.node.XLinkOut); xout_frames.setStreamName("frames")
manip.out.link(xout_frames.input)

xout_dets = p.create(dai.node.XLinkOut); xout_dets.setStreamName("detections")
yolo.out.link(xout_dets.input)

def label_name(idx):
    return labels[idx] if 0 <= idx < len(labels) else str(idx)

def write_atomic_jpg(path, img, quality=80):
    ok, buf = cv2.imencode(".jpg", img, [int(cv2.IMWRITE_JPEG_QUALITY), quality])
    if not ok: return False
    tmp = path + ".tmp"
    with open(tmp, "wb") as f: f.write(buf.tobytes())
    os.replace(tmp, path)
    return True

def safe_box(det, Wf, Hf):
    def _f(val):
        try: return float(val)
        except: return float("nan")
    xmin, ymin, xmax, ymax = map(_f, (getattr(det,"xmin",None), getattr(det,"ymin",None),
                                      getattr(det,"xmax",None), getattr(det,"ymax",None)))
    if any(map(lambda v: v is None or math.isnan(v) or math.isinf(v), [xmin,ymin,xmax,ymax])):
        return None
    x1 = int(max(0, min(Wf-1, round(xmin*Wf))))
    y1 = int(max(0, min(Hf-1, round(ymin*Hf))))
    x2 = int(max(0, min(Wf-1, round(xmax*Wf))))
    y2 = int(max(0, min(Hf-1, round(ymax*Hf))))
    if x2 <= x1 or y2 <= y1: return None
    return x1,y1,x2,y2

stop = False
def _sig(_a,_b):
    global stop
    stop = True
signal.signal(signal.SIGINT, _sig)
signal.signal(signal.SIGTERM, _sig)

with dai.Device(p) as dev:
    qF = dev.getOutputQueue("frames", maxSize=4, blocking=False)
    qD = dev.getOutputQueue("detections", maxSize=4, blocking=False)

    print("✅ Updating:", LATEST)
    frames, t_prev, t_log, fps = 0, time.time(), time.time(), 0.0

    while not stop:
        f = qF.get()          # always get a frame
        d = qD.tryGet()       # detections may be None

        frame = f.getCvFrame()    # 416x416 BGR
        Hf, Wf = frame.shape[:2]
        dets = d.detections if d is not None and hasattr(d, "detections") else []

        for det in dets:
            box = safe_box(det, Wf, Hf)
            if not box: continue
            x1,y1,x2,y2 = box
            name = label_name(int(getattr(det, "label", -1)))
            conf = float(getattr(det, "confidence", 0.0))
            cv2.rectangle(frame, (x1,y1), (x2,y2), (0,255,0), 2)
            cv2.putText(frame, f"{name} {conf:.2f}",
                        (x1, max(15, y1-6)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 1)

        # FPS/clock overlay so you can see it change
        now = time.time()
        dt = now - t_prev
        if dt > 0 and frames > 0:
            fps = 0.9*fps + 0.1*(1.0/dt)
        t_prev = now
        cv2.putText(frame, f"{time.strftime('%H:%M:%S')}  FPS~{fps:.1f}",
                    (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

        write_atomic_jpg(LATEST, frame, JPEG_QUALITY)

        frames += 1
        if now - t_log >= 1.0:
            print(f"[updated] {LATEST}  frames:{frames}  fps~{fps:.1f}")
            t_log = now

    print("✅ Stopped.")
